import 'package:flutter/cupertino.dart';

Color bg_color = Color(0xffdaffed);
Color fg_color = Color(0xff473198);