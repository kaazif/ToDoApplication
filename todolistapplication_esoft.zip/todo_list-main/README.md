# todo_list_app
![todo](https://user-images.githubusercontent.com/46857727/140636716-9e1dc2a8-c26e-42df-a25f-02b9ea8560cc.jpg)
A new Flutter project.

## Requirements
```
  intl: ^0.17.0
  sqflite: ^2.0.0+4
  path_provider: ^2.0.6
  double_back_to_close_app: ^2.0.1
```
